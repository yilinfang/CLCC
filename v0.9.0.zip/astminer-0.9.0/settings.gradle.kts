rootProject.name = "astminer"

include("examples")
