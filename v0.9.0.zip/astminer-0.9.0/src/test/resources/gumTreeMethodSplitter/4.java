class SingleFunction {
    int fun(int args, SingleFunction param) {
        System.out.println("Hello again world!");
        return 0;
    }
}