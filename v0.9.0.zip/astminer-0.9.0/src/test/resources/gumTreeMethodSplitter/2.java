class SingleMethodInnerClass {
    class InnerClass {
        void main(String[] args) {
            System.out.println("Hello world!");
        }
    }
}
