class StringArrayInitialization {

    private String[] array;

    StringArrayInitialization() {
        array = new String[1];
    }
}