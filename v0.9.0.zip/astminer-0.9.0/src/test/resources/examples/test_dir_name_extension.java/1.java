class SingleFunction {
    int x;

    @Override
    void fun(String[] args, int param) {
        System.out.println("Hello again world!");
    }

    public SingleFunction {
        x = 5;
    }
}
